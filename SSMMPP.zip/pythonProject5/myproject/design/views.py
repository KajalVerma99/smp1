from django.shortcuts import render
from django.http import HttpResponse

# Create your views here.
def index(request):
    return render(request, 'design/form.html')

def login(request):
    return render(request, 'design/login.html')

def signup(request):
    return render(request, 'design/signup.html')

def dashboard(request):
    return render(request, 'design/dashboard.html')


