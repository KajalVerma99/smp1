from django.apps import AppConfig


class DesignConfig(AppConfig):
    name = 'design'
