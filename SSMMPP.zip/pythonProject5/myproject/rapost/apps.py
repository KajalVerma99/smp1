from django.apps import AppConfig


class RapostConfig(AppConfig):
    name = 'rapost'
